<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  if ($messageStack->size('header') > 0) {
    echo '<div class="grid_24">' . $messageStack->output('header') . '</div>';
  }
?>

<div id="header" class="grid_24">
  <div id="storeLogo"><?php echo '<a href="' . tep_href_link(FILENAME_DEFAULT) . '">' . tep_image(DIR_WS_IMAGES . 'store_logo.png', STORE_NAME) . '</a>'; ?></div>

  

<script type="text/javascript">
  $("#headerShortcuts").buttonset();
</script>
</div>
<div id="headerShortcuts">
 <?php 
	if(get_customer_type($_SESSION['customer_group_id'])=='admin' || get_customer_type($_SESSION['customer_group_id'])=='storeadmin')
	  {
		 
		 echo  tep_draw_button('New Order/Quote', 'triangle-1-e', tep_href_link('neworder.php', '', 'SSL')).'&nbsp;'.'&nbsp;'.
		
		 tep_draw_button('View all orders', 'triangle-1-e', tep_href_link('allorders.php', '', 'SSL')).'&nbsp;'.'&nbsp;'.
		 	tep_draw_button('Update account info', 'triangle-1-e', tep_href_link(FILENAME_ACCOUNT_EDIT, '', 'SSL')).'&nbsp;'.'&nbsp;'.
		 tep_draw_button('Update address info', 'triangle-1-e', tep_href_link(FILENAME_ADDRESS_BOOK, '', 'SSL')).'&nbsp;'.'&nbsp;'.
		 tep_draw_button('Update pasword', 'triangle-1-e', tep_href_link(FILENAME_ACCOUNT_PASSWORD, '', 'SSL'));
		  if (tep_session_is_registered('customer_id')) {
    echo '&nbsp;'.'&nbsp;'.tep_draw_button(HEADER_TITLE_LOGOFF, null, tep_href_link(FILENAME_LOGOFF, '', 'SSL'));
  }
	  }
 else if(get_customer_type($_SESSION['customer_group_id'])=='storeusers')
	  {
		 
		 echo  
		
		 tep_draw_button('View all orders', 'triangle-1-e', tep_href_link('allordersuser.php', '', 'SSL')).'&nbsp;'.'&nbsp;'.
		 	tep_draw_button('Update account info', 'triangle-1-e', tep_href_link(FILENAME_ACCOUNT_EDIT, '', 'SSL')).'&nbsp;'.'&nbsp;'.
		// tep_draw_button('Update address info', 'triangle-1-e', tep_href_link(FILENAME_ADDRESS_BOOK, '', 'SSL')).'&nbsp;'.'&nbsp;'.
		 tep_draw_button('Update pasword', 'triangle-1-e', tep_href_link(FILENAME_ACCOUNT_PASSWORD, '', 'SSL'));
		  if (tep_session_is_registered('customer_id')) {
    echo '&nbsp;'.'&nbsp;'.tep_draw_button(HEADER_TITLE_LOGOFF, null, tep_href_link(FILENAME_LOGOFF, '', 'SSL'));
  }
	    
		}
		 
		else 
		{
		echo	
		
		 tep_draw_button('New Order/Quote', 'triangle-1-e', tep_href_link('neworder.php', '', 'SSL')).'&nbsp;'.
	//	   tep_draw_button('View all orders user', 'triangle-1-e', tep_href_link('allordersuser.php', '', 'SSL')).'&nbsp;'.'&nbsp;'.
 		  tep_draw_button('My orders', 'triangle-1-e', tep_href_link('allorders.php', '', 'SSL')).'&nbsp;'. 
		 tep_draw_button('No Update account info', 'triangle-1-e', tep_href_link('#', '', 'SSL')).'&nbsp;'.
		 tep_draw_button('No Update address info', 'triangle-1-e', tep_href_link('#', '', 'SSL')).'&nbsp;'.
		 tep_draw_button('No Update pasword', 'triangle-1-e', tep_href_link('#', '', 'SSL'));
		 if (tep_session_is_registered('customer_id')) {
    echo tep_draw_button(HEADER_TITLE_LOGOFF, null, tep_href_link(FILENAME_LOGOFF, '', 'SSL'));
  }
		
	  }
	 ?>
  </div>

<?php
  if (isset($HTTP_GET_VARS['error_message']) && tep_not_null($HTTP_GET_VARS['error_message'])) {
?>
<table border="0" width="100%" cellspacing="0" cellpadding="2">
  <tr class="headerError">
    <td class="headerError"><?php echo htmlspecialchars(stripslashes(urldecode($HTTP_GET_VARS['error_message']))); ?></td>
  </tr>
</table>
<?php
  }

  if (isset($HTTP_GET_VARS['info_message']) && tep_not_null($HTTP_GET_VARS['info_message'])) {
?>
<table border="0" width="100%" cellspacing="0" cellpadding="2">
  <tr class="headerInfo">
    <td class="headerInfo"><?php echo htmlspecialchars(stripslashes(urldecode($HTTP_GET_VARS['info_message']))); ?></td>
  </tr>
</table>
<?php
  }
?>
