<?php

/*

  $Id$



  osCommerce, Open Source E-Commerce Solutions

  http://www.oscommerce.com



  Copyright (c) 2012 osCommerce



  Released under the GNU General Public License

*/

define('EMAIL_SEPARATOR', '------------------------------------------------------');



  require('includes/application_top.php');

  require('includes/classes/http_client.php');



// if the customer is not logged on, redirect them to the login page

  if (!tep_session_is_registered('customer_id')) {

    $navigation->set_snapshot();

    tep_redirect(tep_href_link(FILENAME_LOGIN, '', 'SSL'));

  }

 if(get_customer_type($_SESSION['customer_group_id'])=='storeusers') {

    $navigation->set_snapshot();

    tep_redirect(tep_href_link('allordersuser.php', '', 'SSL'));

  }

// if there is nothing in the customers cart, redirect them to the shopping cart page

  //if ($cart->count_contents() < 1) {

  //  tep_redirect(tep_href_link(FILENAME_SHOPPING_CART));

 // }


  require(DIR_WS_LANGUAGES . $language . '/' . FILENAME_CHECKOUT_SHIPPING);



 



 // dont show left and right block

 $dontshowleftright=1;

  

  require(DIR_WS_INCLUDES . 'template_top.php');

  $request_type = array(array('id' => 'order', 'text' => 'Order'),
                                 array('id' => 'quote', 'text' => 'Quote'),
								 );

   $cat_query = tep_db_query("select a.categories_id, b.categories_name,b.price_a from " . TABLE_CATEGORIES . " a ," .TABLE_CATEGORIES_DESCRIPTION. " b where a.categories_id=b.categories_id and a.parent_id=0 order by b.categories_name");

  			    	//	echo "select a.categories_id, b.categories_name from " . TABLE_CATEGORIES . " a ," .TABLE_CATEGORIES_DESCRIPTION. " b where a.categories_id=b.categories_id and a.parent_id=0 order by b.categories_name";	    

  	    $cat_arrayt = array();

  	       

  		           $cat_arrayt[] = array('id' => '', 'text' => PULL_DOWN_DEFAULT);

//<option value="" selected="selected">Please Select</option><option value="19">ADAPTER</option><option value="49">BASE</option><option value="40">BATTERY</option><option value="98">DESKTOP OTHER</option><option value="58">DESKTOP POWER SUPPLY</option><option value="148">DESKTOP VIDEO CARD</option><option value="37">DVD</option><option value="1">FAN</option><option value="4">FRONT BEZEL</option><option value="61">GREASE</option><option value="43">HDD</option><option value="31">HINGE PAIR</option><option value="46">KEYBOARD BILINGUAL</option><option value="16">KEYBOARD ENGLISH</option><option value="10">LCD BACK COVER</option><option value="114">LCD COMPLETE ASSY</option><option value="52">LCD PANEL ONLY</option><option value="125">LCD WIRE SET</option><option value="55">MOTHERBOARD</option><option value="22">OTHER</option><option value="25">PALMREST</option><option value="7">RAM</option><option value="109">SSD</option><option value="13">SWITCH COVER</option><option value="34">THERMAL MODULE</option><option value="28">WIFI</option><option value="223">Z QUOTE</option>  		           

  			    			    

  			    			              while ($cat = tep_db_fetch_array($cat_query)) {

  			    			                $categories_name =    $cat['categories_name'] ;
											$categories_id =    $cat['categories_id'] ;

      if($cat['categories_id']=='19')$cat['categories_id']=35;

      if($cat['categories_id']=='40')$cat['categories_id']=65;

      if($cat['categories_id']=='49')$cat['categories_id']=0;

      if($cat['categories_id']=='98')$cat['categories_id']=0;

      if($cat['categories_id']=='58')$cat['categories_id']=30;

      if($cat['categories_id']=='148')$cat['categories_id']=110;

      if($cat['categories_id']=='37')$cat['categories_id']=0;

      if($cat['categories_id']=='1')$cat['categories_id']=25;

      if($cat['categories_id']=='4')$cat['categories_id']=25;

      if($cat['categories_id']=='61')$cat['categories_id']=10;

      if($cat['categories_id']=='43')$cat['categories_id']=80;

      if($cat['categories_id']=='31')$cat['categories_id']=30;

      if($cat['categories_id']=='46')$cat['categories_id']=85;

      if($cat['categories_id']=='16')$cat['categories_id']=35;

      if($cat['categories_id']=='10')$cat['categories_id']=27;

      if($cat['categories_id']=='114')$cat['categories_id']=350;

      if($cat['categories_id']=='52')$cat['categories_id']=135;

      if($cat['categories_id']=='125')$cat['categories_id']=27;

      if($cat['categories_id']=='55')$cat['categories_id']=250;

      if($cat['categories_id']=='22')$cat['categories_id']=35;

      if($cat['categories_id']=='25')$cat['categories_id']=45;

      if($cat['categories_id']=='7')$cat['categories_id']=25;

      if($cat['categories_id']=='109')$cat['categories_id']=0;

      if($cat['categories_id']=='13')$cat['categories_id']=30;

      if($cat['categories_id']=='34')$cat['categories_id']=0;

      if($cat['categories_id']=='28')$cat['categories_id']=0;

      if($cat['categories_id']=='223')$cat['categories_id']=0;

      

      

      

  			    			                /*$cat_arrayt[] = array('id' => $cat['categories_id'].':'.$categories_name,

  			    			                                               'text' => $categories_name);*/
																		  
											$cat_arrayt[] = array('id' =>  $categories_id,

  			    			                                               'text' => $categories_name);

  			    			              }

?>
<h1><?php echo 'Place a new Request'; ?></h1>
 <div style="clear: both;"></div>
 <?php if(get_customer_type($_SESSION['customer_group_id'])!='admin') { ?>
<style>
.storeprice
{
visibility:hidden;	
}
</style>
<?php }echo tep_draw_form('neworder', tep_href_link('neworder_process.php', '', 'SSL'), 'post', 'id="neworder"', true) . tep_draw_hidden_field('action', 'process'); ?>

 <script type="text/javascript">

 function updateTextField(s,t)

 {

   /* var select = document.getElementById(s);

    var input = document.getElementById(t);
 var valu = select.value;
    var stts= valu.split(':');

        input.value = stts[0];
*/


$.ajax({
   url:'price.php?p='+s,
    success: function(data){
 	//alert(data);
	var res = data.split("::");
	//return;
	
   $("#"+t).val(res[1]);
   $("#store"+t).html(res[0]);
   if(res[1]==0 || res[1]=='0.00') {
	   
	 $("#Order").hide(); 
	 $("#Orderdisabled").show(); 
	
	 
   } else {
	 $("#Order").show(); 
	 $("#Orderdisabled").hide(); 
	   
   }
 
   
   
    }
   });
 }


 </script>





  <div class="contentText">



    <table border="0" width="100%" cellspacing="1" cellpadding="2">

      <tr>

        <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="4">

	      <tr>
		      <td><b>Manufacturer : </b></td>
		      <td> <?php

	    

	    $manufacturers_query = tep_db_query("select manufacturers_id, manufacturers_name from " . TABLE_MANUFACTURERS . " order by manufacturers_name");

	    

	    $manufacturers_arrayt = array();

	              if (MAX_MANUFACTURERS_LIST < 2) {

	                $manufacturers_arrayt[] = array('id' => '', 'text' => PULL_DOWN_DEFAULT);

	              }

	    

	              while ($manufacturers = tep_db_fetch_array($manufacturers_query)) {

	                $manufacturers_name = ((strlen($manufacturers['manufacturers_name']) > MAX_DISPLAY_MANUFACTURER_NAME_LEN) ? substr($manufacturers['manufacturers_name'], 0, MAX_DISPLAY_MANUFACTURER_NAME_LEN) . '..' : $manufacturers['manufacturers_name']);

	                $manufacturers_arrayt[] = array('id' => $manufacturers['manufacturers_id'],

	                                               'text' => $manufacturers_name);

	              }

	    

	              $content =  tep_draw_pull_down_menu('manufacturers_id', $manufacturers_arrayt, (isset($_POST['manufacturers_id']) ? $_POST['manufacturers_id'] : ''), 'required="required"')  ;

	             

	    

	            echo   $content  ;

	    ?></td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
	      </tr>
          <?php if(get_customer_type($_SESSION['customer_group_id'])=='admin') { ?>

	      <tr>

        <td><b>Customers  : </b></td><td>	<?php 
		 $customers_query = tep_db_query("select customers_id, customers_lastname, customers_firstname from " . TABLE_CUSTOMERS . " order by customers_firstname");
		   $customers_arrayt = array();
		  while ($customers = tep_db_fetch_array($customers_query)) {


	                $customers_arrayt[] = array('id' => $customers['customers_id'],

	                                               'text' =>  $customers['customers_lastname'].' '. $customers['customers_firstname']);

	              }

	    

	              $content =  tep_draw_pull_down_menu('customersid', $customers_arrayt, (isset($_POST['customers_id']) ? $_POST['customers_id'] : ''), '')  ;

	             

	    

	            echo   $content  ;

		
		 ?></td>
         <td></td><td></td>

          </tr>
          <?php } ?>
       

          <tr>

        <td><b>Serial  : 
          <input type="hidden" name="request_type" id="request_type" value="" />
        </b></td><td>	<?php echo tep_draw_input_field('serial_no', '','required=required'); ?></td>
          <td><b>Model  : </b></td><td>	<?php echo tep_draw_input_field('model_no', '','required=required'); ?></td>

          </tr>

      

         

        </table></td>

        

      </tr>

      <tr>

      <td>

      <table border="0" width="100%" cellspacing="5" cellpadding="2">

      <tr>

      		<th>Qty</th>

      	 

      		<th>Part Type</th>

      	 

      		<th>Description</th>

      	 

      		<th>Part Number</th>
      		<th class="storeprice"><?php echo STAPLES_PRICE; ?></th>

      	 

      		<th><?php echo CUSTOMER_PRICE; ?></th>

      	 

       		</tr>

                <tr>

 

		<td valign="top" align="center"><?php echo tep_draw_input_field('cart_quantity1', $_POST['cart_quantity1'], 'size="2" required="required"') ;?></td>

	 

		<td valign="top" align="center"><?php  

			echo  tep_draw_pull_down_menu('parttype1', $cat_arrayt, (isset($_POST['parttype1']) ? $_POST['parttype1'] : ''), ' id="parttype1" onchange="updateTextField(this.value,\'price1\')" required="required"')  ;

		?></td>

 

		<td valign="top" align="center" id="saeed"><?php echo tep_draw_input_field('desc1', $_POST['descr1'],'size="12"');?></td>

 

		<td valign="top" align="center"><?php echo tep_draw_input_field('partnum1', $_POST['partnum1'],'size="8" required="required"');?></td>
		<td valign="top" align="center"><div class="storeprice" id="storeprice1"></div></td>

 

		<td valign="top" align="center"><?php echo tep_draw_input_field('price1', $_POST['price1'],' readonly size="4" required="required" id="price1" ');?></td>

 		</tr>

                <tr>

 

		<td valign="top" align="center"><?php echo tep_draw_input_field('cart_quantity2', $_POST['cart_quantity2'], 'size="2"') ;?></td>

	 

		<td valign="top" align="center"><?php  

					   

			reset($cat_arrayt);		    			    

					    			              echo  tep_draw_pull_down_menu('parttype2', $cat_arrayt, (isset($_POST['parttype2']) ? $_POST['parttype2'] : ''), ' id="parttype2" onchange="updateTextField(this.value,\'price2\')" ')  ;

				?></td>

 

		<td valign="top" align="center"><?php echo tep_draw_input_field('desc2', $_POST['descr2'],'size="12"');?></td>

 

		<td valign="top" align="center"><?php echo tep_draw_input_field('partnum2', $_POST['partnum2'],'size="8"');?></td>
		<td valign="top" align="center"><div class="storeprice" id="storeprice2"></div></td>

 

		<td valign="top" align="center"><?php echo tep_draw_input_field('price2', $_POST['price2'],' readonly size="4" required="required" id="price2" ');?></td>

 		</tr>

                <tr>

 

		<td valign="top" align="center"><?php echo tep_draw_input_field('cart_quantity3', $_POST['cart_quantity3'], 'size="2"') ;?></td>

	 

		<td valign="top" align="center"><?php  

							   

					reset($cat_arrayt);		    			    

							    			              echo  tep_draw_pull_down_menu('parttype3', $cat_arrayt, (isset($_POST['parttype3']) ? $_POST['parttype3'] : ''), ' id="parttype3" onchange="updateTextField(this.value,\'price3\')" ')  ;

						?></td>

 

		<td valign="top" align="center"><?php echo tep_draw_input_field('desc3', $_POST['descr3'],'size="12"');?></td>

 

		<td valign="top" align="center"><?php echo tep_draw_input_field('partnum3', $_POST['partnum3'],'size="8"');?></td>
		<td valign="top" align="center"><div class="storeprice" id="storeprice3"></div></td>

 

		<td valign="top" align="center"><?php echo tep_draw_input_field('price3', $_POST['price3'],' readonly size="4" id="price3" required="required"');?></td>

 		</tr>

                <tr>

	 

		<td valign="top" align="center"><?php echo tep_draw_input_field('cart_quantity4', $_POST['cart_quantity4'], 'size="2"') ;?></td>

 

		<td valign="top" align="center"><?php  

									   

							reset($cat_arrayt);		    			    

									    			              echo  tep_draw_pull_down_menu('parttype4', $cat_arrayt, (isset($_POST['parttype4']) ? $_POST['parttype4'] : ''), ' id="parttype4" onchange="updateTextField(this.value,\'price4\')" ')  ;

								?></td>

 

		<td valign="top" align="center"><?php echo tep_draw_input_field('desc4', $_POST['descr4'],'size="12"');?></td>

 

		<td valign="top" align="center"><?php echo tep_draw_input_field('partnum4', $_POST['partnum4'],'size="8"');?></td>
		<td valign="top" align="center"><div class="storeprice" id="storeprice4"></div></td>

 

		<td valign="top" align="center"><?php echo tep_draw_input_field('price4', $_POST['price4'],' readonly size="4" required="required" id="price4" ');?></td>

 		</tr>

                <tr>

 

		<td valign="top" align="center"><?php echo tep_draw_input_field('cart_quantity5', $_POST['cart_quantity5'], 'size="2"') ;?></td>

 

		<td valign="top" align="center"><?php  

									   

							reset($cat_arrayt);		    			    

									    			              echo  tep_draw_pull_down_menu('parttype5', $cat_arrayt, (isset($_POST['parttype5']) ? $_POST['parttype5'] : ''), ' id="parttype5" onchange="updateTextField(this.value,\'price5\')" ')  ;

								?></td>

 

		<td valign="top" align="center"><?php echo tep_draw_input_field('desc5', $_POST['descr5'],'size="12"');?></td>

 

		<td valign="top" align="center"><?php echo tep_draw_input_field('partnum5', $_POST['partnum5'],'size="8"');?></td>
		<td valign="top" align="center"><div class="storeprice" id="storeprice5"></div></td>

	 

		<td valign="top" align="center"><?php echo tep_draw_input_field('price5', $_POST['price5'],' readonly size="4" required="required" id="price5" ');?></td>

 		</tr>

                <tr>

 

		<td valign="top" align="center"><?php echo tep_draw_input_field('cart_quantity6', $_POST['cart_quantity6'], 'size="2"') ;?></td>

 

		<td valign="top" align="center"><?php  

									   

							reset($cat_arrayt);		    			    

									    			              echo  tep_draw_pull_down_menu('parttype6', $cat_arrayt, (isset($_POST['parttype6']) ? $_POST['parttype6'] : ''), ' id="parttype6" onchange="updateTextField(this.value,\'price6\')" ')  ;

								?></td>

	 

		<td valign="top" align="center"><?php echo tep_draw_input_field('desc6', $_POST['descr6'],'size="12"');?></td>

	 

		<td valign="top" align="center"><?php echo tep_draw_input_field('partnum6', $_POST['partnum6'],'size="8"');?></td>
		<td valign="top" align="center"><div class="storeprice" id="storeprice6"></div></td>

	 

		<td valign="top" align="center"><?php echo tep_draw_input_field('price6', $_POST['price6'],' readonly size="4" required="required" id="price6" ');?></td>

 		</tr>

		 

		

		</table>

      </td></tr>

        <tr><td>

	

	  <table border="0" width="100%" cellspacing="0" cellpadding="2"><tr>

              <td><b>Issue No  : </b></td><td >	<?php echo tep_draw_input_field('issue_no', '','required=required'); ?></td>
                <td><b>PO No (Only for orders) : </b></td><td>	<?php echo tep_draw_input_field('customer_po', '','id="customer_po"'); ?><br /><span style="color:#F00;font-weight:bold;" id = "po_error"></span></td> 
                </tr>

             

                <tr>              <td colspan="4"><b>Notes : </b></td>

		</tr>

		<tr><td colspan="4">	<?php echo tep_draw_textarea_field('notes', 'soft', '70', '7');?></td>

      </tr></table></td></tr>

    </table>

  </div>

  

  

  



	 

 



<div style="float: right;">
<input type="button" name="Orderdisabled" id="Orderdisabled" value="order" class="myButton2" style="display:none;" />
 <input type="submit" name="Order" id="Order" value="order" class="myButton" />&nbsp;
   <input type="submit" name="Quote" id="Quote" value="quote" class="myButton" />
<input type="hidden" id = "type_order_quote" value="" />


 


</div></div>

</div>
</form>
<script>

 $(function() {
$("#Order").click(function() {
	$("#type_order_quote").val('order');
});
$("#neworder").submit(function(e) {
var tmp = $("#type_order_quote").val();
if(tmp=='order') {
	if($("#customer_po").val()=='') {
		e.preventDefault();
		$("#po_error").html('Please enter the Po No');
	}
}
if(tmp=='') {
	if($("#customer_po").val()!='') {
		e.preventDefault();
		$("#po_error").html('PO No is only for orders');
	}
}
});
});
</script>


<?php

  require(DIR_WS_INCLUDES . 'template_bottom.php');

  require(DIR_WS_INCLUDES . 'application_bottom.php');

?>

