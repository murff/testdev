<?php require('includes/application_top.php');
define('EMAIL_SEPARATOR', '------------------------------------------------------');
if($_REQUEST['act']=='save') {
 $price_query = tep_db_query("insert into rfq_order_comment_history(order_id,customer_id,comments)values(".$_REQUEST['cID'].",".$_SESSION['customer_id'].",'".$_REQUEST['comment']."')");
 
 $order_query = tep_db_fetch_array(tep_db_query("select `order/quote`, customer_id from rfq_order where rfq_id = ".$_REQUEST['cID']." order by date_added desc"));
       
	    $rfq_id = ($_REQUEST['cID']);
	
		$email_order = "New comment added to " .strtoupper($order_query['order/quote']).'#'.$rfq_id. " \n" . " \n" . $_REQUEST['comment']. " \n" . " \n". EMAIL_SEPARATOR . "\n\n" ."Added on:". date("Y-m-d").
                 
		
 		" \n" . " \n" . 'View Comment:' . "\n" .EMAIL_SEPARATOR . "\n<a href='http://itemnet.ca/cartest/view_detail.php?id=" .$rfq_id. "'>http://itemnet.ca/cartest/view_detail.php?id=" .$rfq_id. "</a>\n\n" ;
	   
	  //get_customer_id function retun customer id
    // $customer_id=get_customer_id($rfq_id);
	  
	  $customers_email = tep_db_query("select * from customers where customers_id = '" . (int)$order_query['customer_id']. "'");
      $customer_address = tep_db_fetch_array($customers_email);
		
	
	$admin_email = tep_db_query("select c.customers_id,c.customers_firstname,c.customers_lastname, c.customers_email_address, c.customer_group_id, cg.customers_group_id,cg.customers_group_type
	  from customers c, customers_groups cg where c.customer_group_id = cg.customers_group_id and cg.customers_group_type ='storeadmin'");
      $admin_address = tep_db_fetch_array($admin_email);
	 
	 
		  tep_mail($admin_address['customers_firstname'] . ' ' . $admin_address['customers_lastname'], $admin_address['customers_email_address'] ,"New comment  " .strtoupper($order_query['order/quote']).'#'.$rfq_id. "", $email_order, $customer_address['customers_firstname'] . ' ' . $customer_address['customers_lastname'], $customer_address['customers_email_address']);	 

	
	tep_mail($customer_address['customers_firstname'] . ' ' . $customer_address['customers_lastname'], $customer_address['customers_email_address'], "New comment  " .strtoupper($order_query['order/quote']).'#'.$rfq_id. "", $email_order,$admin_address['customers_firstname'] . ' ' . $admin_address['customers_lastname'], $admin_address['customers_email_address'] );
           
         
 
 ?>
 <table width="100%" cellspacing="0" cellpadding="10" border="0">
  <tbody>
  <?php  $comment_his_sql = tep_db_query("select * from rfq_order_comment_history where order_id=".$_REQUEST['cID']."  order by date_added asc");
  while($comment_info = tep_db_fetch_array($comment_his_sql)) {
	  

 	  $gid = get_customer_geoup_id($comment_info['customer_id']); 
	  if(get_customer_type($gid)=='customer' || get_customer_type($gid)=='buyer')
	  { ?>
      	 <tr class="">
        	<th colspan="4" align="left">
                <h3 class="customer"><?=get_customer_fullname($comment_info["customer_id"])?></h3>
                <small>posted on: <?=date('d M, Y',strtotime($comment_info["date_added"]))?></small>
                <p><?=$comment_info["comments"]?></p>
          	</th>
      </tr>
 <?php } else {?>   
     	<tr class="">
        	<td colspan="4" align="left">
                <h3 class="customeradmin"><?=get_customer_fullname($comment_info["customer_id"])?>&nbsp;&nbsp;[<?php echo get_customer_group($gid) ?>]</h3>
                <small>posted on: <?=date('d M, Y',strtotime($comment_info["date_added"]))?></small>
                <p><?=$comment_info["comments"]?></p>
          	</td>
      </tr>
    <?php } }?>  
     
      <tr class="">
        <td colspan="4" align="left"><textarea name="comment_history" id="comment_history" cols="45" rows="5" placeholder="Add comment"></textarea></td>
        </tr>
     <tr class="">
        <td colspan="4" align="left"><div id="loader"><img src="images/opc-ajax-loader.gif" /></div> <input type="button" name="Order" id="Order" value="Save comment" class="myButton" onclick="updateComment();" /></td>
        </tr>
        </tbody></table>         
<?php
}
?>