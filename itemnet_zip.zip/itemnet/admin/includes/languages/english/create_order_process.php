<?php
/*
  $Id: create_order_process.php,v 1 12:25 AM 17/08/2003 frankl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_CREATE', 'Check Customer Details');
define('DEFAULT_PAYMENT_METHOD', "Payment on Local Pickup. We accept cash, Interac, Visa and Master Card.");
define('TEXT_SUBTOTAL', "Subtotal :");
define('TEXT_DISCOUNT', "Discount :");
define('TEXT_DELIVERY', "Delivery :");
define('TEXT_TAX', "Tax :");
define('TEXT_TOTAL', "Total :");
define('TEXT_EMAIL_EXISTS_ERROR', "Cannot create new customer, the customer email address already exists. Use existing customer record.");
?>