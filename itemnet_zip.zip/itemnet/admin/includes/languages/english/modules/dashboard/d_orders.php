<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_ORDERS_TITLE', 'Orders');
define('MODULE_ADMIN_DASHBOARD_ORDERS_DESCRIPTION', 'Show the latest orders');
define('MODULE_ADMIN_DASHBOARD_ORDERS_TOTAL', 'Total');
define('MODULE_ADMIN_DASHBOARD_ORDERS_DATE', 'Date');
define('MODULE_ADMIN_DASHBOARD_ORDERS_ORDER_STATUS', 'Status');
?>
