<?php
/*
  $Id: 
  Updated for osCommerce 2.3.3.4 2013/09/30 - mommaroodles 
  for Separate Pricing Per Customer
       

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Attribute prices for groups');
define('ERROR_NO_ATTRIBUTE_ID', 'No attribute id was given');
define('NUMBER_OF_SAVES', 'Number of saves: ');
define('TABLE_HEADING_GROUP_NAME', 'Group&#160;Name');
define('TABLE_HEADING_DELETE', 'Delete');
define('TABLE_HEADING_INSERT', 'Insert');
define('IMAGE_CLOSE', 'Close');
define('TABLE_HEADING_HIDDEN', 'Hidden');
// BOF copied from includes/languages/products_attributes.php
define('TABLE_HEADING_ID', 'ID');
define('TABLE_HEADING_PRODUCT', 'Product Name');
define('TABLE_HEADING_OPT_NAME', 'Option Name');
define('TABLE_HEADING_OPT_VALUE', 'Option Value');
define('TABLE_HEADING_OPT_PRICE', 'Value Price');
define('TABLE_HEADING_OPT_PRICE_PREFIX', 'Prefix');
// EOF copied from includes/languages/products_attributes.php
?>